# BurntBall LLC Website

A beautiful, modern dark mode website for BurntBall LLC featuring gaming and entertainment content.

## Features

### 🎨 Design
- **Dark Mode**: Beautiful gradient dark theme with modern aesthetics
- **Responsive Design**: Fully responsive across all devices
- **Smooth Animations**: CSS animations and JavaScript interactions
- **Modern UI**: Glassmorphism effects and gradient accents

### 🚀 Interactive Elements
- **Smooth Scrolling**: Navigation links with smooth scroll behavior
- **Scroll Animations**: Elements fade in as you scroll
- **Floating Cards**: Animated cards in the hero section
- **Particle Effects**: Subtle floating particles in the background
- **Progress Bar**: Scroll progress indicator at the top
- **Mobile Menu**: Responsive mobile navigation

### 📱 Sections
1. **Hero Section**: Main landing area with call-to-action buttons
2. **About Section**: Company information and features
3. **Services Section**: Gaming services offered
4. **Contact Section**: Social media links (Discord & Kick)
5. **Footer**: Additional links and social media

### 🔗 External Links
- **Discord**: https://discord.gg/erXXKYbXMT
- **Kick.com**: https://kick.com/burnt-balllofi

## Files Structure

```
burntball-website/
├── index.html          # Main HTML file
├── styles.css          # CSS styling and animations
├── script.js           # JavaScript functionality
└── README.md          # This file
```

## How to Use

1. **Open the website**: Simply open `index.html` in any modern web browser
2. **Navigate**: Use the navigation menu to jump to different sections
3. **Interact**: Click on the Discord and Kick buttons to visit external links
4. **Mobile**: The website is fully responsive and works on mobile devices

## Browser Compatibility

- ✅ Chrome (recommended)
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ Mobile browsers

## Customization

### Colors
The website uses a gradient color scheme:
- Primary: `#ff6b6b` (coral red)
- Secondary: `#4ecdc4` (turquoise)
- Background: Dark gradients from `#0a0a0a` to `#1a1a1a`

### Fonts
- **Primary Font**: Inter (Google Fonts)
- **Icons**: Font Awesome 6.0

## Features in Detail

### Navigation
- Fixed navigation bar with blur effect
- Smooth scrolling to sections
- Mobile-responsive hamburger menu

### Hero Section
- Animated gradient text
- Floating cards with hover effects
- Call-to-action buttons
- Particle background effects

### Animations
- Fade-in animations on scroll
- Hover effects on cards and buttons
- Parallax scrolling effects
- Typing animation for hero title

### Social Integration
- Discord server link with custom styling
- Kick.com streaming link
- Social media icons in footer

## Performance

- Optimized CSS with efficient animations
- Minimal JavaScript for smooth interactions
- Fast loading with CDN resources
- Responsive images and icons

## Future Enhancements

Potential additions:
- Blog section for gaming content
- Tournament registration system
- Live stream embed
- User authentication
- Community forum integration

---

**Created for BurntBall LLC** - Gaming & Entertainment 